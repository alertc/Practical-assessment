export class fetchData {
    
    // getPermission() {   
    //     //ACCESS TOKEN REQUEST
    //     var getAuth = new Request("https://id.twitch.tv/oauth2/token?client_id=9if8cgupe8j7qkgh3mr4kkf8hnjvrq&client_secret=4n75o7ca8mu3qp801d0y6cgqfygk2b&grant_type=client_credentials", {
    //         method: "Post",
    //         headers: {
    //             "Content-Type": "appllication/json",
    //         },
    //     })
    //     async function getAccessToken(request:Request) {
    //         let credentials = []
    //         try {
    //             const response = await fetch(request);
    //             const result = await response.json();
    //             // console.log("Success: ", result["access_token"]);
    //             const token = {
    //                 "access_token": result["access_token"],
    //                 "expires_in": result["expires_in"],
    //                 "token_type": result["token_type"]
    //             }
    //             credentials.push(token)
    //             // console.log(credentials);
    //             return credentials;

    //         } catch (error) {
    //             console.log("Error: ",error);
    //             return credentials;
    //         }
    //     }
    //     return getAccessToken(getAuth);
    // }
    
    gameSearchRequest() {
        var raw = "fields abbreviation,alternative_name,category,checksum,created_at,generation,name,platform_family,platform_logo,slug,summary,updated_at,url,versions,websites;limit 25;";
        var queryDb = fetch("https://7a79n1jwgk.execute-api.us-west-2.amazonaws.com/production/v4/platforms",{
                method: "POST",
                headers: {
                    "x-api-key": "RJVvCArmgo4UcmCeoR3EaRnjgNLN8j19NocN1dd9",
                },
                body: raw,
            }).then(response => {
                var textRes = response.json();
                // console.log(textRes);
                return textRes;
            }).catch(err => {
                console.error(err);
                return err;
            });
   
        return queryDb;
    }

    // fetchGames() {
    //     return this.getPermission();
    // }
    
    // fetchGamesDetails() {
    //     return this.getPermission();
    //     return "Details Optained"
    // }
}