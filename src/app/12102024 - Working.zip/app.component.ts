import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { fetchData } from './backend_services/backend.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
  providers: [fetchData],
})

export class AppComponent {
  constructor(private fetchData: fetchData
  ) {}
  title = 'game_explorer';
  
  gamesList = [];
  searchGames() {
    console.log("Search Initiated")
    this.fetchData.gameSearchRequest().then(data => {{
      console.log(data);
    }})


    // this.fetchData.fetchGames().then((results)=>{
    //   if (results.length !=0) {
    //     this.fetchData.gameSearchRequest()
    //     .then((data)=>{
    //         console.log(data)
    //       }
    //     )
    //   }
    // });
  }
  getGamesDetails() {
    // let gamesDetails = this.fetchData.fetchGamesDetails();
    // console.log("More Details Request Initiated")
    // console.log(gamesDetails);
  }
}
